from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from .models import Property

# house_broker/views.py

from django.shortcuts import render

def property_register(request):
    # Your view logic for property registration
    return render(request, 'house_broker/property_register.html')


def property_list(request):
    properties = Property.objects.all()  # Assuming you have a Property model
    return render(request, 'house_broker/property_list.html', {'properties': properties})