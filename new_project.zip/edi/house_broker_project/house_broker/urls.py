# house_broker_project/urls.py

from django.contrib import admin
from django.urls import path
from house_broker.views import property_list, property_register  # Update this line

urlpatterns = [
    path('admin/', admin.site.urls),
    path('properties/', property_list, name='property_list'),
    path('property/register/', property_register, name='property_register'),
]
